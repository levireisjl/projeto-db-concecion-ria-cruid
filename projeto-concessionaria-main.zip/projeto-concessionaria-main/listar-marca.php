<?php
require_once __DIR__ . '/config.php';

//
// --- EXCLUIR MARCA ---
//
if (isset($_GET['acao']) && $_GET['acao'] === 'excluir') {

    $id = intval($_GET['id'] ?? 0);

    if ($id > 0) {

        $sql = "SELECT * FROM marca WHERE id_marca = {$id}";
        $res = $conn->query($sql);

        if ($res->num_rows > 0) {

            $sqlDelete = "DELETE FROM marca WHERE id_marca = {$id}";
            $resDelete = $conn->query($sqlDelete);

            if ($resDelete) {
                print "<script>alert('Marca excluída com sucesso!');</script>";
            } else {
                print "<script>alert('Erro ao excluir: " . $conn->error . "');</script>";
            }
        } else {
            print "<script>alert('Marca não encontrada!');</script>";
        }
    }

    print "<script>location.href='?page=listar-marca';</script>";
    exit;
}
?>

<h1>Listar Marcas</h1>

<table class="table table-bordered table-striped">
    <thead>
        <tr>
            <th>ID</th>
            <th>Nome da Marca</th>
            <th>Ações</th>
        </tr>
    </thead>

    <tbody>
        <?php
        $sql = "SELECT id_marca, nome_marca FROM marca";
        $result = $conn->query($sql);

        if ($result && $result->num_rows > 0) {

            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>{$row['id_marca']}</td>
                        <td>{$row['nome_marca']}</td>

                        <td>
                            <a href='?page=editar-marca&id={$row['id_marca']}' 
                               class='btn btn-warning'>Editar</a>

                            <a href='?page=listar-marca&acao=excluir&id={$row['id_marca']}' 
                               class='btn btn-danger'
                               onclick=\"return confirm('Tem certeza que deseja excluir esta marca?');\">
                                Excluir
                            </a>
                        </td>
                      </tr>";
            }

        } else {
            echo "<tr><td colspan='3'>Nenhuma marca encontrada</td></tr>";
        }
        ?>
    </tbody>
</table>

<?php require_once __DIR__ . '/config.php'; ?>

<h1>Cadastrar Venda</h1>

<form action="?page=salvar-venda" method="POST">
    <input type="hidden" name="acao" value="cadastrar">

    <!-- Data da venda -->
    <div class="mb-3">
        <label>Data da Venda</label>
        <input type="date" name="data_venda" class="form-control" required>
    </div>

    <!-- Valor da venda -->
    <div class="mb-3">
        <label>Valor da Venda</label>
        <input type="number" name="valor_venda" step="0.01" class="form-control" required>
    </div>

    <!-- Cliente -->
    <div class="mb-3">
        <label>Cliente</label>
        <select name="cliente_id_cliente" class="form-control" required>
            <option value="">Selecione...</option>

            <?php
            $sql = "SELECT id_cliente, nome_cliente FROM cliente";
            $res = $conn->query($sql);

            while ($row = $res->fetch_assoc()) {
                echo "<option value='{$row['id_cliente']}'>{$row['nome_cliente']}</option>";
            }
            ?>
        </select>
    </div>

    <!-- Funcionário -->
    <div class="mb-3">
        <label>Funcionário</label>
        <select name="funcionario_id_funcionario" class="form-control" required>
            <option value="">Selecione...</option>

            <?php
            $sql = "SELECT id_funcionario, nome_funcionario FROM funcionario";
            $res = $conn->query($sql);

            while ($row = $res->fetch_assoc()) {
                echo "<option value='{$row['id_funcionario']}'>{$row['nome_funcionario']}</option>";
            }
            ?>
        </select>
    </div>

    <!-- Modelo -->
    <div class="mb-3">
        <label>Modelo</label>
        <select name="modelo_id_modelo" class="form-control" required>
            <option value="">Selecione...</option>

            <?php
            $sql = "SELECT id_modelo, nome_modelo FROM modelo";
            $res = $conn->query($sql);

            while ($row = $res->fetch_assoc()) {
                echo "<option value='{$row['id_modelo']}'>{$row['nome_modelo']}</option>";
            }
            ?>
        </select>
    </div>

    <button type="submit" class="btn btn-primary">Enviar</button>
</form>

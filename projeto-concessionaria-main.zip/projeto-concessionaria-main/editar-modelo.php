<h1>Editar Modelo</h1><?php
require_once __DIR__ . '/config.php';

$id = intval($_GET['id'] ?? 0);

$sql = "SELECT * FROM modelo WHERE id_modelo = {$id}";
$res = $conn->query($sql);
$row = $res->fetch_assoc();
?>

<h1>Editar Modelo</h1>

<form action="?page=salvar-modelo" method="POST">
    <input type="hidden" name="acao" value="editar">
    <input type="hidden" name="id_modelo" value="<?= $row['id_modelo'] ?>">

    <div class="mb-3">
        <label>Nome</label>
        <input type="text" name="nome_modelo" class="form-control" value="<?= $row['nome_modelo'] ?>" required>
    </div>

    <div class="mb-3">
        <label>Cor</label>
        <input type="text" name="cor_modelo" class="form-control" value="<?= $row['cor_modelo'] ?>" required>
    </div>

    <div class="mb-3">
        <label>Ano</label>
        <input type="number" name="ano_modelo" class="form-control" value="<?= $row['ano_modelo'] ?>" required>
    </div>

    <div class="mb-3">
        <label>Tipo</label>
        <input type="text" name="tipo_modelo" class="form-control" value="<?= $row['tipo_modelo'] ?>" required>
    </div>

    <div class="mb-3">
        <label>ID da Marca</label>
        <input type="number" name="marca_id_marca" class="form-control" value="<?= $row['marca_id_marca'] ?>" required>
    </div>

    <button type="submit" class="btn btn-primary">Salvar Alterações</button>
</form>

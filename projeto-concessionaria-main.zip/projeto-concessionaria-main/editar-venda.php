<?php
require_once __DIR__ . '/config.php';

$id = intval($_GET['id'] ?? 0);

$sql = "SELECT * FROM venda WHERE id_venda = {$id}";
$res = $conn->query($sql);

if (!$res || $res->num_rows == 0) {
    echo "<div class='alert alert-warning'>Venda não encontrada.</div>";
    exit;
}

$row = $res->fetch_assoc();
?>

<h1>Editar Venda</h1>

<form action="?page=salvar-venda" method="POST">
    <input type="hidden" name="acao" value="editar">
    <input type="hidden" name="id_venda" value="<?= htmlspecialchars($row['id_venda']) ?>">

    <div class="mb-3">
        <label>Data da Venda</label>
        <input type="date" name="data_venda" class="form-control" value="<?= htmlspecialchars($row['data_venda']) ?>" required>
    </div>

    <div class="mb-3">
        <label>Valor da Venda</label>
        <input type="number" step="0.01" name="valor_venda" class="form-control" value="<?= htmlspecialchars($row['valor_venda']) ?>" required>
    </div>

    <div class="mb-3">
        <label>Cliente</label>
        <select name="cliente_id_cliente" class="form-control" required>
            <option value="">Selecione...</option>
            <?php
            $sqlC = "SELECT id_cliente, nome_cliente FROM cliente";
            $resC = $conn->query($sqlC);
            while ($c = $resC->fetch_assoc()) {
                $sel = ($c['id_cliente'] == $row['cliente_id_cliente']) ? "selected" : "";
                echo "<option value='{$c['id_cliente']}' $sel>" . htmlspecialchars($c['nome_cliente']) . "</option>";
            }
            ?>
        </select>
    </div>

    <div class="mb-3">
        <label>Funcionário</label>
        <select name="funcionario_id_funcionario" class="form-control" required>
            <?php
            $sqlF = "SELECT id_funcionario, nome_funcionario FROM funcionario";
            $resF = $conn->query($sqlF);
            while ($f = $resF->fetch_assoc()) {
                $sel = ($f['id_funcionario'] == $row['funcionario_id_funcionario']) ? "selected" : "";
                echo "<option value='{$f['id_funcionario']}' $sel>" . htmlspecialchars($f['nome_funcionario']) . "</option>";
            }
            ?>
        </select>
    </div>

    <div class="mb-3">
        <label>Modelo</label>
        <select name="modelo_id_modelo" class="form-control" required>
            <?php
            $sqlM = "SELECT id_modelo, nome_modelo FROM modelo";
            $resM = $conn->query($sqlM);
            while ($m = $resM->fetch_assoc()) {
                $sel = ($m['id_modelo'] == $row['modelo_id_modelo']) ? "selected" : "";
                echo "<option value='{$m['id_modelo']}' $sel>" . htmlspecialchars($m['nome_modelo']) . "</option>";
            }
            ?>
        </select>
    </div>

    <button type="submit" class="btn btn-primary">Salvar Alterações</button>
</form>

<!-- salvar-funcionario -->


<?php
require_once __DIR__ . '/config.php';

switch (@$_REQUEST['acao']) {

    case 'cadastrar':
        $nome = $conn->real_escape_string($_POST['nome_funcionario']);
        $cpf = $conn->real_escape_string($_POST['cpf_funcionario']);
        $email = $conn->real_escape_string($_POST['email_funcionario']);
        $telefone = $conn->real_escape_string($_POST['telefone_funcionario']);

        $sql = "INSERT INTO funcionario (nome_funcionario, cpf_funcionario, email_funcionario, telefone_funcionario)
                VALUES ('{$nome}', '{$cpf}', '{$email}', '{$telefone}')";

        $res = $conn->query($sql);

        if ($res) {
            print "<script>alert('Funcionário cadastrado com sucesso!');</script>";
        } else {
            print "<script>alert('Erro: " . $conn->error . "');</script>";
        }
        print "<script>location.href='?page=listar-funcionario';</script>";
        break;

    case 'editar':
        $id = intval($_POST['id_funcionario']);
        $nome = $conn->real_escape_string($_POST['nome_funcionario']);
        $cpf = $conn->real_escape_string($_POST['cpf_funcionario']);
        $email = $conn->real_escape_string($_POST['email_funcionario']);
        $telefone = $conn->real_escape_string($_POST['telefone_funcionario']);

        $sql = "UPDATE funcionario 
                SET nome_funcionario='{$nome}', 
                    cpf_funcionario='{$cpf}', 
                    email_funcionario='{$email}', 
                    telefone_funcionario='{$telefone}'
                WHERE id_funcionario={$id}";

        $res = $conn->query($sql);

        if ($res) {
            print "<script>alert('Funcionário atualizado com sucesso!');</script>";
        } else {
            print "<script>alert('Erro: " . $conn->error . "');</script>";
        }
        print "<script>location.href='?page=listar-funcionario';</script>";
        break;

    default:
        print "<script>location.href='?page=listar-funcionario';</script>";
        break;
}
?>

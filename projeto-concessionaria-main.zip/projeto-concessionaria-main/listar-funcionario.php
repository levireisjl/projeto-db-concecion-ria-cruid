<?php
require_once __DIR__ . '/config.php';

//
// --- EXCLUIR FUNCIONÁRIO ---
//
if (isset($_GET['acao']) && $_GET['acao'] === 'excluir') {

    $id = intval($_GET['id'] ?? 0);

    if ($id > 0) {

        // Verifica se existe
        $sql = "SELECT * FROM funcionario WHERE id_funcionario = {$id}";
        $res = $conn->query($sql);

        if ($res->num_rows > 0) {

            // Exclui
            $sqlDelete = "DELETE FROM funcionario WHERE id_funcionario = {$id}";
            $resDelete = $conn->query($sqlDelete);

            if ($resDelete) {
                print "<script>alert('Funcionário excluído com sucesso!');</script>";
            } else {
                print "<script>alert('Erro ao excluir: " . $conn->error . "');</script>";
            }
        } else {
            print "<script>alert('Funcionário não encontrado!');</script>";
        }
    }

    print "<script>location.href='?page=listar-funcionario';</script>";
    exit;
}
?>

<h1>Listar Funcionário</h1>

<table class="table table-bordered table-striped">
    <thead>
        <tr>
            <th>ID</th>
            <th>Nome do Funcionário</th>
            <th>Email</th>
            <th>Telefone</th>
            <th>CPF</th>
            <th>Ações</th>
        </tr>
    </thead>

    <tbody>
        <?php
        $sql = "SELECT id_funcionario, nome_funcionario, email_funcionario, telefone_funcionario, cpf_funcionario 
                FROM funcionario";

        $result = $conn->query($sql);

        if ($result && $result->num_rows > 0) {

            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>{$row['id_funcionario']}</td>
                        <td>{$row['nome_funcionario']}</td>
                        <td>{$row['email_funcionario']}</td>
                        <td>{$row['telefone_funcionario']}</td>
                        <td>{$row['cpf_funcionario']}</td>

                        <td>
                            <a href='?page=editar-funcionario&id={$row['id_funcionario']}' 
                               class='btn btn-warning'>Editar</a>

                            <a href='?page=listar-funcionario&acao=excluir&id={$row['id_funcionario']}' 
                               class='btn btn-danger'
                               onclick=\"return confirm('Tem certeza que deseja excluir este funcionário? Esta ação não pode ser desfeita.');\">
                                Excluir
                            </a>
                        </td>
                      </tr>";
            }

        } else {
            echo "<tr><td colspan='6'>Nenhum funcionário encontrado</td></tr>";
        }
        ?>
    </tbody>
</table>

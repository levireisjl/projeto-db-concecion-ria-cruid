<?php
require_once __DIR__ . '/config.php';

// Mostra erros (temporário — ok durante dev)
ini_set('display_errors', 1);
error_reporting(E_ALL);

$acao = $_POST['acao'] ?? '';

if ($acao == "cadastrar") {

    // obtém e limpa entradas
    $data_venda      = $conn->real_escape_string($_POST['data_venda'] ?? '');
    $valor_venda     = floatval($_POST['valor_venda'] ?? 0);
    $cliente_id      = intval($_POST['cliente_id_cliente'] ?? 0);
    $funcionario_id  = intval($_POST['funcionario_id_funcionario'] ?? 0);
    $modelo_id       = intval($_POST['modelo_id_modelo'] ?? 0);

    // validações básicas
    if ($cliente_id <= 0 || $funcionario_id <= 0 || $modelo_id <= 0) {
        print "<script>alert('Por favor, selecione cliente, funcionário e modelo corretamente.');</script>";
        print "<script>history.back();</script>";
        exit;
    }

    $sql = "INSERT INTO venda (
                data_venda,
                valor_venda,
                cliente_id_cliente,
                funcionario_id_funcionario,
                modelo_id_modelo
            ) VALUES (
                '{$data_venda}',
                '{$valor_venda}',
                {$cliente_id},
                {$funcionario_id},
                {$modelo_id}
            )";

    if ($conn->query($sql)) {
        print "<script>alert('Venda cadastrada com sucesso!');</script>";
        print "<script>location.href='?page=listar-venda';</script>";
        exit;
    } else {
        // mostra erro detalhado durante dev
        print "<script>alert('Erro ao cadastrar venda: " . addslashes($conn->error) . "');</script>";
        print "<script>history.back();</script>";
        exit;
    }

} elseif ($acao == "editar") {

    $id_venda        = intval($_POST['id_venda'] ?? 0);
    $data_venda      = $conn->real_escape_string($_POST['data_venda'] ?? '');
    $valor_venda     = floatval($_POST['valor_venda'] ?? 0);
    $cliente_id      = intval($_POST['cliente_id_cliente'] ?? 0);
    $funcionario_id  = intval($_POST['funcionario_id_funcionario'] ?? 0);
    $modelo_id       = intval($_POST['modelo_id_modelo'] ?? 0);

    if ($id_venda <= 0) {
        print "<script>alert('ID da venda inválido.');</script>";
        print "<script>location.href='?page=listar-venda';</script>";
        exit;
    }

    if ($cliente_id <= 0 || $funcionario_id <= 0 || $modelo_id <= 0) {
        print "<script>alert('Por favor, selecione cliente, funcionário e modelo corretamente.');</script>";
        print "<script>history.back();</script>";
        exit;
    }

    $sql = "UPDATE venda SET
                data_venda = '{$data_venda}',
                valor_venda = '{$valor_venda}',
                cliente_id_cliente = {$cliente_id},
                funcionario_id_funcionario = {$funcionario_id},
                modelo_id_modelo = {$modelo_id}
            WHERE id_venda = {$id_venda}";

    if ($conn->query($sql)) {
        print "<script>alert('Venda atualizada com sucesso!');</script>";
        print "<script>location.href='?page=listar-venda';</script>";
        exit;
    } else {
        print "<script>alert('Erro ao atualizar venda: " . addslashes($conn->error) . "');</script>";
        print "<script>history.back();</script>";
        exit;
    }

} else {
    // ação desconhecida
    print "<script>location.href='?page=listar-venda';</script>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Concessionária Reis</title>
	<link rel="stylesheet" href="css/bootstrap.min.css">

	<style>
		/* Paleta azul, branco e cinza */
		body {
			background: #f0f4f8;
		}
		.navbar {
			background: #1f3b73 !important;
		}
		.navbar-brand {
			font-weight: 700;
			color: #ffffff !important;
		}
		.card-home {
			border-radius: 12px;
			box-shadow: 0 4px 10px rgba(0,0,0,0.06);
			transition: transform .18s ease, box-shadow .18s ease;
			background: white;
		}
		.card-home:hover {
			transform: translateY(-6px);
			box-shadow: 0 10px 30px rgba(0,0,0,0.12);
		}
		.btn-custom {
			background: #1f3b73;
			color: white;
			border-radius: 8px;
			border: none;
		}
		.btn-custom:hover {
			background: #14284d;
			color: #eee;
		}
		.small-muted { color:#6b7280; }
		.footer {
			background: #ffffffaa;
			padding: 18px 0;
			border-top: 1px solid rgba(0,0,0,0.04);
			margin-top: 40px;
		}
	</style>
</head>
<body>
	<nav class="navbar navbar-expand-lg navbar-dark">
	  <div class="container-fluid">
	    <a class="navbar-brand" href="index.php">Concessionária Reis</a>

	    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Alternar navegação">
	      <span class="navbar-toggler-icon"></span>
	    </button>

	    <div class="collapse navbar-collapse" id="navbarSupportedContent">
	      <ul class="navbar-nav me-auto mb-2 mb-lg-0">

	        <!-- Funcionários -->
	        <li class="nav-item dropdown">
	          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Funcionários</a>
	          <ul class="dropdown-menu">
	            <li><a class="dropdown-item" href="?page=cadastrar-funcionario">Cadastrar</a></li>
	            <li><a class="dropdown-item" href="?page=listar-funcionario">Listar</a></li>
	          </ul>
	        </li>

	        <!-- Clientes -->
	        <li class="nav-item dropdown">
	          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Clientes</a>
	          <ul class="dropdown-menu">
	            <li><a class="dropdown-item" href="?page=cadastrar-cliente">Cadastrar</a></li>
	            <li><a class="dropdown-item" href="?page=listar-cliente">Listar</a></li>
	          </ul>
	        </li>

	        <!-- Marcas -->
	        <li class="nav-item dropdown">
	          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Marcas</a>
	          <ul class="dropdown-menu">
	            <li><a class="dropdown-item" href="?page=cadastrar-marca">Cadastrar</a></li>
	            <li><a class="dropdown-item" href="?page=listar-marca">Listar</a></li>
	          </ul>
	        </li>

	        <!-- Modelos -->
	        <li class="nav-item dropdown">
	          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Modelos</a>
	          <ul class="dropdown-menu">
	            <li><a class="dropdown-item" href="?page=cadastrar-modelo">Cadastrar</a></li>
	            <li><a class="dropdown-item" href="?page=listar-modelo">Listar</a></li>
	          </ul>
	        </li>

	        <!-- Vendas -->
	        <li class="nav-item dropdown">
	          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Vendas</a>
	          <ul class="dropdown-menu">
	            <li><a class="dropdown-item" href="?page=cadastrar-venda">Cadastrar</a></li>
	            <li><a class="dropdown-item" href="?page=listar-venda">Listar</a></li>
	          </ul>
	        </li>

	      </ul>

		  <form class="d-flex me-2" role="search" onsubmit="event.preventDefault(); document.getElementById('searchInput').classList.toggle('is-invalid');">
	        <input id="searchInput" class="form-control me-2" type="search" placeholder="Pesquisar (ainda não)" aria-label="Buscar">
	        <button class="btn btn-outline-light" type="submit">Buscar</button>
	      </form>

		  <div class="d-flex align-items-center">
		  	<button class="btn btn-sm btn-light me-2" data-bs-toggle="modal" data-bs-target="#helpModal">Ajuda</button>
		  	<div class="text-white small-muted me-2">Usuário: Admin</div>
		  </div>

	    </div>
	  </div>
	</nav>

	<div class="container mt-4">
		<div class="row mb-3">
			<div class="col-12">
				<?php
					switch (@$_REQUEST['page']) {

						// funcionário
						case 'cadastrar-funcionario': include('cadastrar-funcionario.php'); break;
						case 'listar-funcionario': include('listar-funcionario.php'); break;
						case 'editar-funcionario': include('editar-funcionario.php'); break;
						case 'salvar-funcionario': include('salvar-funcionario.php'); break;
						

						// cliente
						case 'cadastrar-cliente': include('cadastrar-cliente.php'); break;
						case 'listar-cliente': include('listar-cliente.php'); break;
						case 'editar-cliente': include('editar-cliente.php'); break;
						case 'salvar-cliente': include('salvar-cliente.php'); break;

						// marca
						case 'cadastrar-marca': include('cadastrar-marca.php'); break;
						case 'listar-marca': include('listar-marca.php'); break;
						case 'editar-marca': include('editar-marca.php'); break;
						case 'salvar-marca': include('salvar-marca.php'); break;

						// modelo
						case 'cadastrar-modelo': include('cadastrar-modelo.php'); break;
						case 'listar-modelo': include('listar-modelo.php'); break;
						case 'editar-modelo': include('editar-modelo.php'); break;
						case 'salvar-modelo': include('salvar-modelo.php'); break;

						// venda
						case 'cadastrar-venda': include('cadastrar-venda.php'); break;
						case 'listar-venda': include('listar-venda.php'); break;
						case 'editar-venda': include('editar-venda.php'); break;
						case 'salvar-venda': include('salvar-venda.php'); break;

						// HOME
						default:
							?>
						<!-- Header Home -->
						<div class="d-flex justify-content-between align-items-center mb-3">
							<div>
								<h1 class="h3 mb-0">Seja bem-vindo à Concessionária Reis</h1>
								<div class="small text-muted">Painel de controle • Gerencie suas operações</div>
							</div>
							<div>
								<a href="?page=cadastrar-venda" class="btn btn-custom me-2">Registrar Venda</a>
								<a href="?page=cadastrar-cliente" class="btn btn-outline-secondary">Novo Cliente</a>
							</div>
						</div>

						<!-- Dashboard cards -->
						<div class="row g-3 mb-4">
							<div class="col-md-3">
								<div class="card card-home p-3">
									<div class="d-flex justify-content-between align-items-start">
										<div>
											<h5 class="mb-1">Funcionários</h5>
											<p class="small-muted mb-2">Total cadastrado</p>
											<h3>—</h3>
										</div>
										<span class="badge bg-primary">Gerir</span>
									</div>
									<a href="?page=listar-funcionario" class="stretched-link"></a>
								</div>
							</div>

							<div class="col-md-3">
								<div class="card card-home p-3">
									<div class="d-flex justify-content-between align-items-start">
										<div>
											<h5 class="mb-1">Clientes</h5>
											<p class="small-muted mb-2">Total de clientes</p>
											<h3>—</h3>
										</div>
										<span class="badge bg-info">CRM</span>
									</div>
									<a href="?page=listar-cliente" class="stretched-link"></a>
								</div>
							</div>

							<div class="col-md-3">
								<div class="card card-home p-3">
									<div class="d-flex justify-content-between align-items-start">
										<div>
											<h5 class="mb-1">Modelos</h5>
											<p class="small-muted mb-2">Veículos cadastrados</p>
											<h3>—</h3>
										</div>
										<span class="badge bg-secondary">Estoque</span>
									</div>
									<a href="?page=listar-modelo" class="stretched-link"></a>
								</div>
							</div>

							<div class="col-md-3">
								<div class="card card-home p-3">
									<div class="d-flex justify-content-between align-items-start">
										<div>
											<h5 class="mb-1">Vendas</h5>
											<p class="small-muted mb-2">Últimos 30 dias</p>
											<h3>—</h3>
										</div>
										<span class="badge bg-success">Financeiro</span>
									</div>
									<a href="?page=listar-venda" class="stretched-link"></a>
								</div>
							</div>
						</div>

						<!-- Quick actions + Recent activity -->
						<div class="row">
							<div class="col-md-6 mb-3">
								<div class="card card-home p-3">
									<h5>Atalhos rápidos</h5>
									<div class="d-flex gap-2 flex-wrap mt-2">
										<a href="?page=cadastrar-funcionario" class="btn btn-sm btn-outline-primary">Novo funcionário</a>
										<a href="?page=cadastrar-cliente" class="btn btn-sm btn-outline-primary">Novo cliente</a>
										<a href="?page=cadastrar-marca" class="btn btn-sm btn-outline-primary">Nova marca</a>
										<a href="?page=cadastrar-modelo" class="btn btn-sm btn-outline-primary">Novo modelo</a>
										<a href="?page=cadastrar-venda" class="btn btn-sm btn-custom">Nova venda</a>
									</div>
								</div>
							</div>

							<div class="col-md-6 mb-3">
								<div class="card card-home p-3">
									<h5>Últimas ações</h5>
									<ul class="list-group list-group-flush mt-2">
										<li class="list-group-item">Nula — Não tem ações — <span class="small-muted">Nunca</span></li>
									</ul>
								</div>
							</div>
						</div>

						<!-- VIDEO SECTION -->
						<div class="row mb-4">
							<div class="col-12">
								<div class="card card-home p-3">
									<h5 class="mb-3">Video principal</h5>

									<div class="ratio ratio-16x9">
										<iframe src="https://www.youtube.com/embed/cdAMARZK_CM?si=4iyWApgSX3JehU1o"
											title="YouTube video player" allowfullscreen
											allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share">
										</iframe>
									</div>

								</div>
							</div>
						</div>

						<!-- Info / ajuda -->
						<div class="row">
							<div class="col-md-8">
								<div class="card card-home p-3">
									<h5>Sobre o sistema</h5>
									<p class="small-muted">Este é um sistema de gerenciamento de concessionária feito para estudos.</p>
									<div class="mt-2">
										<button class="btn btn-sm btn-custom" data-bs-toggle="modal" data-bs-target="#helpModal">Abrir ajuda</button>
										<a href="?page=listar-venda" class="btn btn-sm btn-outline-secondary">Ver Relatórios</a>
									</div>
								</div>
							</div>

							<div class="col-md-4">
								<div class="card card-home p-3">
									<h6>Notificações</h6>
									<p class="small-muted mb-1">Nenhuma notificação nova</p>
									<button class="btn btn-sm btn-outline-primary">Ver histórico</button>
								</div>
							</div>
						</div>

						<?php
						break;

					}
				?>
			</div>
		</div>

		<!-- Footer -->
		<div class="footer text-center">
			<div class="container">
				<small class="text-muted">© <?php echo date('Y'); ?> Concessionária Reis — Sistema acadêmico de Levi Oliveira dos Reis - RGM:43630421</small>
			</div>
		</div>
	</div>

	<!-- Help Modal -->
	<div class="modal fade" id="helpModal" tabindex="-1" aria-labelledby="helpModalLabel" aria-hidden="true">
	  <div class="modal-dialog modal-lg modal-dialog-centered">
	    <div class="modal-content">
	      <div class="modal-header">
	        <h5 class="modal-title" id="helpModalLabel">Ajuda rápida</h5>
	        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
	      </div>
	      <div class="modal-body">
	        <p>Use o menu para cadastrar e listar dados. Dicas rápidas:</p>
	        <ul>
	        	<li>Para evitar exclusões acidentais, sempre confirme as mensagens de confirmação.</li>
	        	<li> "Seja forte e corajoso. Não tenha medo, pois o Senhor, o seu Deus, estará com você por onde você andar" (Josué 1:9).</li>
	        	<li>Deus Abençoe</li>
	        </ul>
	      </div>
	      <div class="modal-footer">
	        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
	      </div>
	    </div>
	  </div>
	</div>

	<script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>

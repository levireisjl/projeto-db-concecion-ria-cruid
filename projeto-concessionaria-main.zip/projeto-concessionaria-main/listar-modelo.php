<h1>Listar Modelo</h1><?php
require_once __DIR__ . '/config.php';

//
// --- EXCLUIR MODELO ---
//
if (isset($_GET['acao']) && $_GET['acao'] === 'excluir') {

    $id = intval($_GET['id'] ?? 0);

    if ($id > 0) {

        // Verifica se existe
        $sql = "SELECT * FROM modelo WHERE id_modelo = {$id}";
        $res = $conn->query($sql);

        if ($res->num_rows > 0) {

            $sqlDelete = "DELETE FROM modelo WHERE id_modelo = {$id}";
            $resDelete = $conn->query($sqlDelete);

            if ($resDelete) {
                print "<script>alert('Modelo excluído com sucesso!');</script>";
            } else {
                print "<script>alert('Erro ao excluir: " . $conn->error . "');</script>";
            }

        } else {
            print "<script>alert('Modelo não encontrado!');</script>";
        }
    }

    print "<script>location.href='?page=listar-modelo';</script>";
    exit;
}
?>

<h1>Listar Modelos</h1>

<table class="table table-bordered table-striped">
    <thead>
        <tr>
            <th>ID</th>
            <th>Nome</th>
            <th>Cor</th>
            <th>Ano</th>
            <th>Tipo</th>
            <th>ID Marca</th>
            <th>Ações</th>
        </tr>
    </thead>

    <tbody>
        <?php
        $sql = "SELECT * FROM modelo";
        $result = $conn->query($sql);

        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {

                echo "<tr>
                        <td>{$row['id_modelo']}</td>
                        <td>{$row['nome_modelo']}</td>
                        <td>{$row['cor_modelo']}</td>
                        <td>{$row['ano_modelo']}</td>
                        <td>{$row['tipo_modelo']}</td>
                        <td>{$row['marca_id_marca']}</td>

                        <td>
                            <a href='?page=editar-modelo&id={$row['id_modelo']}' class='btn btn-warning'>Editar</a>

                            <a href='?page=listar-modelo&acao=excluir&id={$row['id_modelo']}'
                               class='btn btn-danger'
                               onclick=\"return confirm('Tem certeza que deseja excluir este modelo?');\">
                                Excluir
                            </a>
                        </td>
                      </tr>";
            }

        } else {
            echo "<tr><td colspan='7'>Nenhum modelo encontrado</td></tr>";
        }
        ?>
    </tbody>
</table>

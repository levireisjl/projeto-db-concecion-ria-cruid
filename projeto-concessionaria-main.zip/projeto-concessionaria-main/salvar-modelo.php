<?php
require_once __DIR__ . '/config.php';

switch (@$_REQUEST['acao']) {

    case 'cadastrar':

        $nome  = $conn->real_escape_string($_POST['nome_modelo']);
        $cor   = $conn->real_escape_string($_POST['cor_modelo']);
        $ano   = intval($_POST['ano_modelo']);
        $tipo  = $conn->real_escape_string($_POST['tipo_modelo']);
        $marca = intval($_POST['marca_id_marca']);

        $sql = "INSERT INTO modelo (nome_modelo, cor_modelo, ano_modelo, tipo_modelo, marca_id_marca)
                VALUES ('{$nome}', '{$cor}', {$ano}, '{$tipo}', {$marca})";

        $res = $conn->query($sql);

        if ($res) {
            print "<script>alert('Modelo cadastrado com sucesso!');</script>";
        } else {
            print "<script>alert('Erro: " . $conn->error . "');</script>";
        }

        print "<script>location.href='?page=listar-modelo';</script>";
        break;

    case 'editar':

        $id    = intval($_POST['id_modelo']);
        $nome  = $conn->real_escape_string($_POST['nome_modelo']);
        $cor   = $conn->real_escape_string($_POST['cor_modelo']);
        $ano   = intval($_POST['ano_modelo']);
        $tipo  = $conn->real_escape_string($_POST['tipo_modelo']);
        $marca = intval($_POST['marca_id_marca']);

        $sql = "UPDATE modelo SET
                    nome_modelo='{$nome}',
                    cor_modelo='{$cor}',
                    ano_modelo={$ano},
                    tipo_modelo='{$tipo}',
                    marca_id_marca={$marca}
                WHERE id_modelo={$id}";

        $res = $conn->query($sql);

        if ($res) {
            print "<script>alert('Modelo atualizado com sucesso!');</script>";
        } else {
            print "<script>alert('Erro: " . $conn->error . "');</script>";
        }

        print "<script>location.href='?page=listar-modelo';</script>";
        break;

    default:
        print "<script>location.href='?page=listar-modelo';</script>";
        break;
}
?>

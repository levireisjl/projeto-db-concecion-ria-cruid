<?php
require_once __DIR__ . '/config.php';

switch (@$_REQUEST['acao']) {

    // -----------------------------
    // CADASTRAR CLIENTE
    // -----------------------------
    case 'cadastrar':

        $nome = $conn->real_escape_string($_POST['nome_cliente']);
        $cpf = $conn->real_escape_string($_POST['cpf_cliente']);
        $email = $conn->real_escape_string($_POST['email_cliente']);
        $telefone = $conn->real_escape_string($_POST['telefone_cliente']);
        $endereco = $conn->real_escape_string($_POST['endereco_cliente']);
        $data_nasc = $conn->real_escape_string($_POST['dt_nasc_cliente']);

        $sql = "INSERT INTO cliente 
                (nome_cliente, cpf_cliente, email_cliente, telefone_cliente, endereco_cliente, dt_nasc_cliente)
                VALUES 
                ('{$nome}', '{$cpf}', '{$email}', '{$telefone}', '{$endereco}', '{$data_nasc}')";

        $res = $conn->query($sql);

        if ($res) {
            print "<script>alert('Cliente cadastrado com sucesso!');</script>";
        } else {
            print "<script>alert('Erro: " . $conn->error . "');</script>";
        }

        print "<script>location.href='?page=listar-cliente';</script>";
        break;

    // -----------------------------
    // EDITAR CLIENTE
    // -----------------------------
    case 'editar':

        $id = intval($_POST['id_cliente']);
        $nome = $conn->real_escape_string($_POST['nome_cliente']);
        $cpf = $conn->real_escape_string($_POST['cpf_cliente']);
        $email = $conn->real_escape_string($_POST['email_cliente']);
        $telefone = $conn->real_escape_string($_POST['telefone_cliente']);
        $endereco = $conn->real_escape_string($_POST['endereco_cliente']);
        $data_nasc = $conn->real_escape_string($_POST['dt_nasc_cliente']);

        $sql = "UPDATE cliente 
                SET nome_cliente='{$nome}',
                    cpf_cliente='{$cpf}',
                    email_cliente='{$email}',
                    telefone_cliente='{$telefone}',
                    endereco_cliente='{$endereco}',
                    dt_nasc_cliente='{$data_nasc}'
                WHERE id_cliente={$id}";

        $res = $conn->query($sql);

        if ($res) {
            print "<script>alert('Cliente atualizado com sucesso!');</script>";
        } else {
            print "<script>alert('Erro: " . $conn->error . "');</script>";
        }

        print "<script>location.href='?page=listar-cliente';</script>";
        break;

    // -----------------------------
    // AÇÃO PADRÃO
    // -----------------------------
    default:
        print "<script>location.href='?page=listar-cliente';</script>";
        break;
}
?>

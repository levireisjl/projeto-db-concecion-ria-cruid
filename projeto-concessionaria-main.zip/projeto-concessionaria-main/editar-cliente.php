<?php
require_once __DIR__ . '/config.php';

$id = intval($_GET['id'] ?? 0);

$sql = "SELECT * FROM cliente WHERE id_cliente = {$id}";
$res = $conn->query($sql);
$row = $res->fetch_assoc();
?>

<h1>Editar Cliente</h1>

<form action="?page=salvar-cliente" method="POST">
    <input type="hidden" name="acao" value="editar">
    <input type="hidden" name="id_cliente" value="<?= $row['id_cliente'] ?>">

    <div class="mb-3">
        <label>Nome</label>
        <input type="text" name="nome_cliente" class="form-control" value="<?= $row['nome_cliente'] ?>" required>
    </div>

    <div class="mb-3">
        <label>CPF</label>
        <input type="text" name="cpf_cliente" class="form-control" value="<?= $row['cpf_cliente'] ?>" required>
    </div>

    <div class="mb-3">
        <label>Email</label>
        <input type="email" name="email_cliente" class="form-control" value="<?= $row['email_cliente'] ?>" required>
    </div>

    <div class="mb-3">
        <label>Telefone</label>
        <input type="text" name="telefone_cliente" class="form-control" value="<?= $row['telefone_cliente'] ?>" required>
    </div>

    <div class="mb-3">
        <label>Endereço</label>
        <input type="text" name="endereco_cliente" class="form-control" value="<?= $row['endereco_cliente'] ?>" required>
    </div>

    <div class="mb-3">
        <label>Data de Nascimento</label>
        <input type="date" name="dt_nasc_cliente" class="form-control" value="<?= $row['dt_nasc_cliente'] ?>" required>
    </div>

    <button type="submit" class="btn btn-primary">Salvar Alterações</button>
</form>

<?php
require_once __DIR__ . '/config.php';

//
// --- EXCLUIR CLIENTE ---
//
if (isset($_GET['acao']) && $_GET['acao'] === 'excluir') {

    $id = intval($_GET['id'] ?? 0);

    if ($id > 0) {

        // Verifica se o cliente existe
        $sql = "SELECT * FROM cliente WHERE id_cliente = {$id}";
        $res = $conn->query($sql);

        if ($res->num_rows > 0) {

            // Exclui o cliente
            $sqlDelete = "DELETE FROM cliente WHERE id_cliente = {$id}";
            $resDelete = $conn->query($sqlDelete);

            if ($resDelete) {
                print "<script>alert('Cliente excluído com sucesso!');</script>";
            } else {
                print "<script>alert('Erro ao excluir: " . $conn->error . "');</script>";
            }

        } else {
            print "<script>alert('Cliente não encontrado!');</script>";
        }
    }

    print "<script>location.href='?page=listar-cliente';</script>";
    exit;
}
?>

<h1>Listar Cliente</h1>

<table class="table table-bordered table-striped">
    <thead>
        <tr>
            <th>ID</th>
            <th>Nome</th>
            <th>Email</th>
            <th>Telefone</th>
            <th>CPF</th>
            <th>Ações</th>
        </tr>
    </thead>

    <tbody>
        <?php
        $sql = "SELECT id_cliente, nome_cliente, email_cliente, telefone_cliente, cpf_cliente 
                FROM cliente";

        $result = $conn->query($sql);

        if ($result && $result->num_rows > 0) {

            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>{$row['id_cliente']}</td>
                        <td>{$row['nome_cliente']}</td>
                        <td>{$row['email_cliente']}</td>
                        <td>{$row['telefone_cliente']}</td>
                        <td>{$row['cpf_cliente']}</td>

                        <td>
                            <a href='?page=editar-cliente&id={$row['id_cliente']}' 
                               class='btn btn-warning'>Editar</a>

                            <a href='?page=listar-cliente&acao=excluir&id={$row['id_cliente']}' 
                               class='btn btn-danger'
                               onclick=\"return confirm('Tem certeza que deseja excluir este cliente? Esta ação não pode ser desfeita.');\">
                                Excluir
                            </a>
                        </td>
                      </tr>";
            }

        } else {
            echo "<tr><td colspan='6'>Nenhum cliente encontrado</td></tr>";
        }
        ?>
    </tbody>
</table>

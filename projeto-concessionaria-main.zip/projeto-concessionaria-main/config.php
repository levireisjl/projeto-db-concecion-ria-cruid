<?php
define('HOST', 'localhost');
define('USER', 'root');
define('PASS', '');
define('NAME', 'concessionaria2122m');

$conn = new mysqli(HOST, USER, PASS, NAME);

if ($conn->connect_errno) {
    die("Falha na conexão: " . $conn->connect_error);
}

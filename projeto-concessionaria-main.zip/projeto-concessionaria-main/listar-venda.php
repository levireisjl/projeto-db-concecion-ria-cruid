<?php
require_once __DIR__ . '/config.php';

//
// --- EXCLUIR VENDA ---
//
if (isset($_GET['acao']) && $_GET['acao'] === 'excluir') {

    $id = intval($_GET['id'] ?? 0);

    if ($id > 0) {

        // Verifica se existe
        $sql = "SELECT * FROM venda WHERE id_venda = {$id}";
        $res = $conn->query($sql);

        if ($res->num_rows > 0) {

            // Exclui
            $sqlDelete = "DELETE FROM venda WHERE id_venda = {$id}";
            $resDelete = $conn->query($sqlDelete);

            if ($resDelete) {
                print "<script>alert('Venda excluída com sucesso!');</script>";
            } else {
                print "<script>alert('Erro ao excluir: {$conn->error}');</script>";
            }

        } else {
            print "<script>alert('Venda não encontrada!');</script>";
        }
    }

    print "<script>location.href='?page=listar-venda';</script>";
    exit;
}
?>

<h1>Listar Vendas</h1>

<table class="table table-bordered table-striped">
    <thead>
        <tr>
            <th>ID</th>
            <th>Data</th>
            <th>Valor</th>
            <th>Funcionário</th>
            <th>Modelo</th>
            <th>Ações</th>
        </tr>
    </thead>

    <tbody>
        <?php
        $sql = "SELECT 
                    v.id_venda, 
                    v.data_venda, 
                    v.valor_venda, 

                    f.nome_funcionario,
                    m.nome_modelo

                FROM venda v
                JOIN funcionario f ON f.id_funcionario = v.funcionario_id_funcionario
                JOIN modelo m ON m.id_modelo = v.modelo_id_modelo";

        $result = $conn->query($sql);

        if ($result && $result->num_rows > 0) {

            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>{$row['id_venda']}</td>
                        <td>{$row['data_venda']}</td>
                        <td>R$ {$row['valor_venda']}</td>
                        <td>{$row['nome_funcionario']}</td>
                        <td>{$row['nome_modelo']}</td>

                        <td>
                            <a href='?page=editar-venda&id={$row['id_venda']}' 
                               class='btn btn-warning'>Editar</a>

                            <a href='?page=listar-venda&acao=excluir&id={$row['id_venda']}' 
                               class='btn btn-danger'
                               onclick=\"return confirm('Tem certeza que deseja excluir esta venda?');\">
                                Excluir
                            </a>
                        </td>
                      </tr>";
            }

        } else {
            echo "<tr><td colspan='6'>Nenhuma venda encontrada</td></tr>";
        }
        ?>
    </tbody>
</table>

<?php
require_once __DIR__ . '/config.php';

switch (@$_REQUEST['acao']) {

    case 'cadastrar':

        $nome = $conn->real_escape_string($_POST['nome_marca']);

        $sql = "INSERT INTO marca (nome_marca)
                VALUES ('{$nome}')";

        $res = $conn->query($sql);

        if ($res) {
            print "<script>alert('Marca cadastrada com sucesso!');</script>";
        } else {
            print "<script>alert('Erro: " . $conn->error . "');</script>";
        }

        print "<script>location.href='?page=listar-marca';</script>";
        break;

    case 'editar':

        $id = intval($_POST['id_marca']);
        $nome = $conn->real_escape_string($_POST['nome_marca']);

        $sql = "UPDATE marca 
                SET nome_marca='{$nome}'
                WHERE id_marca={$id}";

        $res = $conn->query($sql);

        if ($res) {
            print "<script>alert('Marca atualizada com sucesso!');</script>";
        } else {
            print "<script>alert('Erro: " . $conn->error . "');</script>";
        }

        print "<script>location.href='?page=listar-marca';</script>";
        break;

    default:
        print "<script>location.href='?page=listar-marca';</script>";
        break;
}
?>
